/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bankbalanceproject;

import java.util.Scanner;

/**
 *
 * @author CAPACITI-JHB
 */
// BankAccount class encapsulates user credentials and banking operations
class BankAccount {
    private final String username;
    private final String password;
    private double balance;
    // Constructor to initialize the BankAccount with username, password, and initial balance
    public BankAccount(String username, String password, double initialBalance) {
        this.username = username;
        this.password = password;
        this.balance = initialBalance;
    }
    // Checks if the credentials match
    public boolean login(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }
    // Returns current account balance
    public double getBalance() {
        return balance;
    }
    // Deposits a valid positive amount to the account
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.printf("Deposit successful! New balance: $%.2f%n", balance);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }
    // Withdraws amount if sufficient balance exists
    public boolean withdraw(double amount) {  if (amount <= 0) {
            System.out.println("Withdrawal amount must be positive.");
            return false;
        }
        if (amount <= balance) {
            balance -= amount;
            System.out.printf("Withdrawal successful! Remaining balance: $%.2f%n", balance);
            return true;
        } else {
            System.out.println("Insufficient funds for withdrawal.");
            return false;
        }
    }
}

public class BankBalanceProject {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        BankAccount account = new BankAccount("user123", "password123", 1000.00 );        
                
        System.out.println("Welcome to the Simple Bank Application!");
        
        //Login Phase
        int loginAttempts = 3;
        boolean authenticated = false;
        
        while (loginAttempts > 0 && !authenticated){
            System.out.print("Enter usename:");
            String inputUsername = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String inputPassword = scanner.nextLine();
            
            if (account.login(inputUsername, inputPassword)) {
                authenticated = true;
                System.out.println("Login Successful");
                
            } else {
                loginAttempts--;
                System.out.printf("Incorrect credentials.Attempts left: %d%n\"", loginAttempts);
            }        
        }
        if (!authenticated){
            System.out.println("Too many failed attempts. Exiting Program");
            scanner.close();
            return;
        }
        // Main Menu Loop
        boolean running = true;
        while (running) {
            System.out.println("\\n--- Main Menu ---");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit Funds");
            System.out.println("3. Withdraw Funds");
            System.out.println("4. Logout");
            
            System.out.println("Please choose an option (1-4): ");
            String choiceInput = scanner.nextLine();
            
            switch (choiceInput) {
                case "1":
                    System.out.printf("\"Your current balance is: $%.2f%n\"",account.getBalance());
                    break;
                case "2": 
                    System.out.print("Enter Deposit amount: ");
                    try{
                        double depositAmount = Double.parseDouble(scanner.nextLine());
                        account.deposit(depositAmount);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input! Please enter a valid number."); 
                    }
                      break;
                case "3":
                    System.out.print("Enter withdrawal amount: ");
                    try {
                        double withdrawalAmount = Double.parseDouble(scanner.nextLine());
                        account.withdraw(withdrawalAmount);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input! Please enter a valid number.");
                    }
                    break;
                case "4":    
                    System.out.println("Logging out... Thank you for using the Simple Bank Application.");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please select a number between 1 and 4.");
            }
        }
        
        scanner.close();
    }
}
